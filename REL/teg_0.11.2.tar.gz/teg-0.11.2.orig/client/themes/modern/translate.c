/*	$Id: translate.c,v 1.2 2002/05/13 04:02:27 riq Exp $	*/
/*
 * Translatable strings.
 * DO NOT compile it as part of your application.
 */

char *s=N_("South America");
char *s=N_("Argentina");
char *s=N_("Brazil");
char *s=N_("Chile")
char *s=N_("Colombia");
char *s=N_("Peru");
char *s=N_("Uruguay");

char *s=N_("North America");
char *s=N_("Mexico");
char *s=N_("California");
char *s=N_("Oregon");
char *s=N_("New York");
char *s=N_("Alaska");
char *s=N_("Yukon");
char *s=N_("Canada");
char *s=N_("Terranova");
char *s=N_("Labrador");
char *s=N_("Greenland");

char *s=N_("Africa");
char *s=N_("Sahara");
char *s=N_("Zaire");
char *s=N_("Etiopia");
char *s=N_("Egypt");
char *s=N_("Madagascar");
char *s=N_("South Africa");

char *s=N_("Oceania");
char *s=N_("Western Australia");
char *s=N_("Borneo");
char *s=N_("Eastern Australia");
char *s=N_("Sumatra");

char *s=N_("Europe");
char *s=N_("Spain");
char *s=N_("France");
char *s=N_("Germany");
char *s=N_("Italy");
char *s=N_("Poland");
char *s=N_("Russia");
char *s=N_("Sweden");
char *s=N_("Great Britain");
char *s=N_("Iceland");

char *s=N_("Asia");
char *s=N_("Arabia");
char *s=N_("Israel");
char *s=N_("Turkey");
char *s=N_("India");
char *s=N_("Malaysia");
char *s=N_("Iran");
char *s=N_("Gobi");
char *s=N_("China");
char *s=N_("Mongolia");
char *s=N_("Siberia");
char *s=N_("Aral");
char *s=N_("Tartary");
char *s=N_("Taymir");
char *s=N_("Katchatka");
char *s=N_("Japan");
